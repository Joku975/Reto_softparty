<?php
include("conn.php");

if (!isset($_GET['id'])) {
    die("ID no especificado.");
}

$id = $_GET['id'];

// Buscar los datos
$sql = "SELECT * FROM user WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();
$registro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$registro) {
    die("Registro no encontrado.");
}

// Calcular tiempo total y valor
$entrada = new DateTime($registro['hora_entrada']);
$salida = new DateTime($registro['hora_salida']);
$intervalo = $entrada->diff($salida);
$tiempo_total = $intervalo->format('%h horas %i minutos');

// Valor a pagar (ejemplo: tarifa por hora)
$tarifa = $registro['tarifa'] ?? 5000; 
$horas = $intervalo->h + ($intervalo->days * 24);
if ($intervalo->i > 0) $horas += 1; // redondeo a la hora siguiente
$valor_pagar = $horas * $tarifa;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle del Registro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2>Datos del registro</h2>
    <ul class="list-group">
        <li class="list-group-item"><strong>Nombre:</strong> <?= htmlspecialchars($registro['name']) ?></li>
        <li class="list-group-item"><strong>Documento:</strong> <?= htmlspecialchars($registro['document']) ?></li>
        <li class="list-group-item"><strong>Contacto:</strong> <?= htmlspecialchars($registro['numero_contacto']) ?></li>
        <li class="list-group-item"><strong>Placa:</strong> <?= htmlspecialchars($registro['placa']) ?></li>
        <li class="list-group-item"><strong>Tipo de vehículo:</strong> <?= htmlspecialchars($registro['tipo_vehiculo']) ?></li>
        <li class="list-group-item"><strong>Hora de entrada:</strong> <?= $registro['hora_entrada'] ?></li>
        <li class="list-group-item"><strong>Hora de salida:</strong> <?= $registro['hora_salida'] ?></li>
        <li class="list-group-item"><strong>Tiempo total:</strong> <?= $tiempo_total ?></li>
        <li class="list-group-item"><strong>Valor a pagar:</strong> $<?= number_format($valor_pagar, 0, ',', '.') ?></li>
    </ul>

    <a href="pdf.php?id=<?= $registro['id'] ?>" class="btn btn-danger mt-3">Descargar PDF</a>
</body>
</html>
