<?php
require 'dompdf-3.1.2/autoload.inc.php';
include("conn.php");

use Dompdf\Dompdf;

if (!isset($_GET['id'])) {
    die("ID no especificado.");
}

$id = $_GET['id'];
$sql = "SELECT * FROM user WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();
$registro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$registro) {
    die("Registro no encontrado.");
}

$entrada = new DateTime($registro['hora_entrada']);
$salida = new DateTime($registro['hora_salida']);
$intervalo = $entrada->diff($salida);
$tiempo_total = $intervalo->format('%h horas %i minutos');
$tarifa = $registro['tarifa'] ?? 5000;
$horas = $intervalo->h + ($intervalo->days * 24);
if ($intervalo->i > 0) $horas += 1;
$valor_pagar = $horas * $tarifa;

// Generar HTML para el PDF
$html = "
<h2>Comprobante de registro</h2>
<p><strong>Nombre:</strong> {$registro['name']}</p>
<p><strong>Documento:</strong> {$registro['document']}</p>
<p><strong>Contacto:</strong> {$registro['numero_contacto']}</p>
<p><strong>Placa:</strong> {$registro['placa']}</p>
<p><strong>Tipo de vehículo:</strong> {$registro['tipo_vehiculo']}</p>
<p><strong>Hora de entrada:</strong> {$registro['hora_entrada']}</p>
<p><strong>Hora de salida:</strong> {$registro['hora_salida']}</p>
<p><strong>Tiempo total:</strong> {$tiempo_total}</p>
<p><strong>Valor a pagar:</strong> $" . number_format($valor_pagar, 0, ',', '.') . "</p>
";

// Generar PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("comprobante.pdf", ["Attachment" => true]);
