<?php
include("app/conn.php"); // tu archivo de conexión con PDO

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $sql = "INSERT INTO user (name, document, numero_contacto, placa, tipo_vehiculo, hora_entrada, tarifa, hora_salida) 
                VALUES (:name, :document, :numero_contacto, :placa, :tipo_vehiculo, :hora_entrada, :tarifa, :hora_salida)";

        $stmt = $conn->prepare($sql);

        $stmt->bindParam(':name', $_POST['name']);
        $stmt->bindParam(':document', $_POST['document']);
        $stmt->bindParam(':numero_contacto', $_POST['numero_contacto']);
        $stmt->bindParam(':placa', $_POST['placa']);
        $stmt->bindParam(':tipo_vehiculo', $_POST['tipo_vehiculo']);
        $stmt->bindParam(':hora_entrada', $_POST['hora_entrada']);
        $stmt->bindParam(':tarifa', $_POST['tarifa']);
        $stmt->bindParam(':hora_salida', $_POST['hora_salida']);

        if ($stmt->execute()) {
            $last_id = $conn->lastInsertId();
            header("Location: app/registro.php?id=" . $last_id);
            exit();
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="container">
        <div class="card">
            <div class="card-body">
                <!-- Bloque de alertas -->
                <?php if (isset($msg)) { ?>
                    <div class="alert alert-<?php echo $msg[1]; ?> alert-dismissible fade show">
                        <strong>Alerta:</strong> <?php echo $msg[0]; ?>
                    </div>
                <?php } ?>

                <div class="text-center">
                    <img src="../assets/img/logo.png" alt="Logo" width="72" height="72">
                    <h1 class="display-6">Registro del vehiculo</h1>
                </div>

                <form action="" method="post" enctype="application/x-www-form-urlencoded" class="w-100">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nombre completo:</label>
                        <input type="text" class="form-control w-100" id="name" name="name" placeholder="Ingrese tu nombre completo" required>
                    </div>

                    <div class="mb-3">
                        <label for="document" class="form-label">Documento de identidad:</label>
                        <input type="number" class="form-control w-100" id="document" name="document" placeholder="Ingrese tu documento de identidad" required>
                    </div>

                    <div class="mb-3">
                        <label for="numero_contacto" class="form-label">Numero de contacto</label>
                        <input type="number" class="form-control w-100" id="numero_contacto" name="numero_contacto" placeholder="Ingrese su numero de contacto" required>
                    </div>

                    <div class="mb-3">
                        <label for="placa" class="form-label">Placa</label>
                        <input type="text" class="form-control w-100" id="placa" name="placa" placeholder="Ingrese tu placa" required>
                    </div>

                    <div class="mb-3">
                        <label for="tipo_vehiculo" class="form-label">Tipo de vehiculo</label>
                        <select class="form-select w-100" id="tipo_vehiculo" name="tipo_vehiculo" required>
                            <option value="" disabled selected>Selecciona una opción</option>
                            <option value="1">Bicicleta</option>
                            <option value="2">Moto</option>
                            <option value="3">Carro</option>
                            <option value="4">Carros grandes</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="hora_entrada" class="form-label">Hora de entrada del vehiculo</label>
                        <input type="datetime-local" class="form-control w-100" id="hora_entrada" name="hora_entrada" placeholder="Ingrese la hora de entrada" required>
                    </div>
                    <div class="mb-3">
                        <label for="hora_salida" class="form-label">Hora de salida del vehiculo</label>
                        <input type="datetime-local" class="form-control w-100" id="hora_salida" name="hora_salida" placeholder="Ingrese la hora de entrada" required>
                    </div>
                    <div class="d-grid">
                        <button class="btn btn-light text-dark" type="submit" name="btn-reg">Registrar</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>

</html>